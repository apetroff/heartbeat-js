# The Watch List

Visit http://www.watchlistapp.com from your mobile device or Webkit browser for a live demo.

Visit http://github.com/senchalearn/Watchlist for the source.
